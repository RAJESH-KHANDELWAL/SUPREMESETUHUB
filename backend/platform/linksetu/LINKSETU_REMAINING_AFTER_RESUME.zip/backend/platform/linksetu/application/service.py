"""LINKSETU application experience service."""


class LinkSetuApplicationService:
    """Manage applications for jobs, opportunities, and selected professional services in LINKSETU."""

    platform_name = "LINKSETU"

    def create_application(self, applicant_id: str, target_id: str, application_type: str = "job") -> dict:
        return {
            "platform": self.platform_name,
            "status": "active",
        }

    def get_application(self, application_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "items": [],
        }

    def get_applicant_applications(self, applicant_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "items": [],
        }

    def update_status(self, application_id: str, status: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def withdraw_application(self, application_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "withdrawn",
        }
