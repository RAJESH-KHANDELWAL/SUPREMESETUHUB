"""LINKSETU APPLICATION EXPERIENCE."""

from .service import LinkSetuApplicationService

__all__ = ["LinkSetuApplicationService"]
