"""LINKSETU endorsement experience service."""


class LinkSetuEndorsementService:
    """Manage professional skill endorsements in LINKSETU."""

    platform_name = "LINKSETU"

    def create_endorsement(self, author_id: str, recipient_id: str, skill: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "active",
        }

    def get_endorsements(self, user_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "items": [],
        }

    def get_skill_endorsements(self, user_id: str, skill: str) -> dict:
        return {
            "platform": self.platform_name,
            "items": [],
        }

    def remove_endorsement(self, endorsement_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "removed",
        }
