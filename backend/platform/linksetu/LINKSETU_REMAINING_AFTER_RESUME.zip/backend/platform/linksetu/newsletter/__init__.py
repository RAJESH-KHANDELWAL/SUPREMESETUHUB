"""LINKSETU NEWSLETTER EXPERIENCE."""

from .service import LinkSetuNewsletterService

__all__ = ["LinkSetuNewsletterService"]
