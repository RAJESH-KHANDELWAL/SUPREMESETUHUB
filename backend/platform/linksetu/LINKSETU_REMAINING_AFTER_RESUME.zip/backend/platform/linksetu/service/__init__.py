"""LINKSETU SERVICE EXPERIENCE."""

from .service import LinkSetuServiceService

__all__ = ["LinkSetuServiceService"]
