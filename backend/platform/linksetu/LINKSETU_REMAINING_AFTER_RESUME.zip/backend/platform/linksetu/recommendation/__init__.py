"""LINKSETU RECOMMENDATION EXPERIENCE."""

from .service import LinkSetuRecommendationService

__all__ = ["LinkSetuRecommendationService"]
