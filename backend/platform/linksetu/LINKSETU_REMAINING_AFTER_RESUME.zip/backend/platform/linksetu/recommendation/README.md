# LINKSETU RECOMMENDATION

Manage professional and platform recommendations between LINKSETU users.

## ARCHITECTURE RULE

This is a LINKSETU platform experience layer. It must reuse the MAIN BASE FOUNDATION and must not create duplicate profile, authentication, storage, notification, or infrastructure engines.

Production persistence, permissions, moderation, analytics, and integrations can be connected later.
