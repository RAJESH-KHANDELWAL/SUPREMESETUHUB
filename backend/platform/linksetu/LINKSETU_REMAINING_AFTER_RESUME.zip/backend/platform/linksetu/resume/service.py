"""LINKSETU resume experience service."""


class LinkSetuResumeService:
    """Manage professional resumes in LINKSETU."""

    platform_name = "LINKSETU"

    def create_resume(self, user_id: str, title: str, summary: str = "") -> dict:
        return {
            "platform": self.platform_name,
            "status": "active",
        }

    def get_resume(self, resume_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "items": [],
        }

    def update_resume(self, resume_id: str, title: str | None = None, summary: str | None = None) -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def add_experience(self, resume_id: str, company: str, role: str, description: str = "") -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def add_education(self, resume_id: str, institution: str, qualification: str, field: str = "") -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def add_skill(self, resume_id: str, skill: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def add_certification(self, resume_id: str, name: str, issuer: str = "") -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def set_visibility(self, resume_id: str, visibility: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def update_status(self, resume_id: str, status: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "updated",
        }

    def delete_resume(self, resume_id: str) -> dict:
        return {
            "platform": self.platform_name,
            "status": "deleted",
        }
