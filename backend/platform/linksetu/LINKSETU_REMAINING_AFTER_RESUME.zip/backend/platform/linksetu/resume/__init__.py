"""LINKSETU RESUME EXPERIENCE."""

from .service import LinkSetuResumeService

__all__ = ["LinkSetuResumeService"]
