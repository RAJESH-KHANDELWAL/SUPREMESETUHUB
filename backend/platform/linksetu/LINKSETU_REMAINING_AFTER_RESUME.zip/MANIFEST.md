# LINKSETU REMAINING AFTER RESUME

Includes the RESUME module plus the remaining planned modules after RESUME:

- resume
- service
- newsletter
- article
- recommendation
- endorsement
- application
- creator

These are foundation scaffolds, not production API/database integrations.
